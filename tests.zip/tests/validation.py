#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 21 17:59:56 2026

@author: vithyali
"""

import pytest
import requests
URL = "http://localhost:8000"

#READ
def test_READ():
    try:
        response_GET = requests.get(f"{URL}/findings", timeout=10)
    except requests.exceptions.ConnectionError:
        pytest.fail("READ: server not connected") 
    except requests.exceptions.Timeout:
        pytest.fail("READ: system took too long to respond")
    #Status code validation
    assert response_GET.status_code == 200
    assert isinstance(response_GET.json(),dict)
    #Response Structure 
    #Outer Structure
    data = response_GET.json() 
    assert "items" in data
    assert "total" in data
    assert "page" in data
    assert "per_page" in data
    assert isinstance(data["items"],list)
    #Inner Structure
    for inn_data in data["items"]:
        assert "id" in inn_data
        assert "asset_id" in inn_data
        assert "vulnerability_id" in inn_data
        assert "status" in inn_data
        assert "detected_at" in inn_data
        assert "resolved_at" in inn_data
        assert "scanner" in inn_data
        assert "notes" in inn_data
        assert "is_dismissed" in inn_data
    
    print("API STATUS CODE:", response_GET.status_code)
    #DATA CORRECTNESS
    #OUTER DATA CORRECTNESS
    assert isinstance(data["total"], int)       
    assert isinstance(data["page"], int)        
    assert isinstance(data["per_page"], int)
    assert data["total"] >= 0
    assert data["page"]  >= 1
    #INNER DATA CORRECTNESS
    for inn_data in data["items"]:
        assert isinstance(inn_data["id"], int)
        assert isinstance(inn_data["status"], str)
        assert isinstance(inn_data["is_dismissed"], bool)
        print("dataid is:", inn_data["id"])